my_value = 42
