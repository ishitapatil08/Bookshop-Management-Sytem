from metaflow.plugins.frameworks._orig.pytorch import (
    PytorchParallelDecorator,
    setup_torch_distributed,
)


class NewPytorchParallelDecorator(PytorchParallelDecorator):
    pass
