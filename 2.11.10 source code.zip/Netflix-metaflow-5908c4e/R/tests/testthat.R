library(testthat)
library(metaflow)

test_check("metaflow")
